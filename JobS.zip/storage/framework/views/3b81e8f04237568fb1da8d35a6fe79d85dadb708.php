

<?php $__env->startSection('title', 'Chọn Mục Tìm Kiếm'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">

  <!-- START SIGN-IN -->
  <section class="bg-auth">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-xl-7 col-lg-7 col-12">
                  <div class="card auth-box">
                      <div class="row g-0">
                          
                          <div class="col-lg-12">
                              <div class="auth-content card-body p-5 h-100 text-white">
                                  <div class="w-100">
                                      <div class="text-center mb-4">
                                          <h5>Jobcy !</h5>
                                          <p class="text-white-70">Bạn đang tìm kiếm gì?</p>
                                      </div>
										<?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <form method="POST" action="<?php echo e(route('site.type.save')); ?>">
                                          <?php echo csrf_field(); ?>
                                          <input type="hidden" class="form-control" name="type" value="<?php echo e(config('constants.USER.TYPE.COMPANY')); ?>" required>
                                          <div class="text-center mb-4">
                                              <button type="submit" class="btn btn-danger btn-hover w-100">Tôi muốn tìm ứng viên</button>
                                          </div>
                                      </form>

                                      <form method="POST" action="<?php echo e(route('site.type.save')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" class="form-control" name="type" value="<?php echo e(config('constants.USER.TYPE.USER')); ?>" required>
                                        <div class="text-center mb-2">
                                            <button type="submit" class="btn btn-white btn-hover w-100">Tôi muốn tìm việc</button>
                                        </div>
                                     </form>
                                      
                                  </div>
                              </div>
                          </div><!--end col-->
                      </div><!--end row-->
                  </div><!--end auth-box-->
              </div><!--end col-->
          </div><!--end row-->
      </div><!--end container-->
  </section>
  <!-- END SIGN-IN -->
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Site.Auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/site/auth/type.blade.php ENDPATH**/ ?>