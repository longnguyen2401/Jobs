

<?php $__env->startSection('title', 'Company'); ?>

<?php $__env->startSection('page', 'List'); ?>

<?php echo $__env->make('admin.components.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/admin/company/index.blade.php ENDPATH**/ ?>