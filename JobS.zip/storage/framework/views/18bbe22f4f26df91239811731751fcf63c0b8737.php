

<?php $__env->startSection('title', 'Đăng Nhập'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">

    <!-- START SIGN-IN -->
    <section class="bg-auth">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-12">
                    <div class="card auth-box">
                        <div class="row g-0">
                            <div class="col-lg-6 text-center">
                                <div class="card-body p-4">
                                    <a href="index.html">
                                        <img src="<?php echo e(asset('assets/site/images/logo-light.png')); ?>" alt="" class="logo-light">
                                        <img src="<?php echo e(asset('assets/site/images/logo-dark.png')); ?>" alt="" class="logo-dark">
                                    </a>
                                    <div class="mt-5">
                                        <img src="<?php echo e(asset('assets/site/images/sign-in.png')); ?>" alt="" class="img-fluid">
                                    </div>
                                </div>
                            </div><!--end col-->
                            <div class="col-lg-6">
                                <div class="auth-content card-body p-5 h-100 text-white">
                                    <div class="w-100">
                                        <div class="text-center mb-4">
                                            <h5>Jobcy !</h5>
                                            <p class="text-white-70">Đăng Nhập Để Tiếp Tục.</p>
                                        </div>
                                        <form method="POST" action="<?php echo e(route('site.auth')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <label for="usernameInput" class="form-label">Email</label>
                                                <input type="text" class="form-control" id="email" name="email" placeholder="Nhập email" required>
                                                
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-4">
                                                <label for="passwordInput" class="form-label">Password</label>
                                                <input type="password" class="form-control" id="password" name="password" placeholder="Nhập password" required>

                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger mt-3"><?php echo e($password); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="text-center mb-4">
                                                <button type="submit" class="btn btn-white btn-hover w-100">Sửa Đăng nhập | cho nhập password khi login bằng google</button>
                                            </div>
                                            <div class="text-center">
                                                <a id="login-goolge" class="btn btn-white btn-hover w-100" href="">
                                                    Đăng nhập bằng google
                                                </a>
                                            
                                            </div>
                                        </form>
                                        
                                    </div>
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->
                    </div><!--end auth-box-->
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    </section>
    <!-- END SIGN-IN -->
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/site/js/login-google.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Site.Auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/site/auth/login.blade.php ENDPATH**/ ?>