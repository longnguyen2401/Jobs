

<?php $__env->startSection('title', 'Trang Chủ'); ?>

<?php if(auth()->check()): ?>
    <p>Welcome, <?php echo e(auth()->user()->name); ?>!</p>
<?php else: ?>
    <p>Please log in to continue.</p>
<?php endif; ?>
<?php echo $__env->make('Site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/site/home/home.blade.php ENDPATH**/ ?>