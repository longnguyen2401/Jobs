

<?php $__env->startSection('title', $metadata['list']['detail']->name . ' Job'); ?>

<?php $__env->startSection('page', 'List'); ?>

<?php $__env->slot('list'); ?>
    <?php echo $metadata['list'] = $metadata['list']['list']; ?> 
<?php $__env->endSlot(); ?>
<?php echo $__env->make('admin.components.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/admin/job/index.blade.php ENDPATH**/ ?>