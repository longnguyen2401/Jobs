

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-12">
                        <div class="p-2">
                            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/' . $metadata['prefix'] . '/' . $metadata['data']->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <?php $__currentLoopData = $metadata['form']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label" for="simpleinput"><?php echo e($form['name']); ?></label>
                                        <div class="col-md-10">
                                        <?php switch($form['component']):
                                            case ('input'): ?>

                                                <input type="<?php echo e($form['type']); ?>" class="form-control" name="<?php echo e($form['key']); ?>" value="<?php echo e($metadata['data']->{$form['key']}); ?>">
                                                    
                                                <?php break; ?>

                                            <?php case ('textarea'): ?>

                                                <textarea class="form-control" rows="5" name="<?php echo e($form['key']); ?>"><?php echo e($metadata['data']->{$form['key']}); ?></textarea>

                                                <?php break; ?>

                                            <?php case ('image'): ?>
                                                <div class="mb-2">
                                                    <img width="200px" src="<?php echo e(asset('storage/uploads/' . $metadata['data']->{$form['key']})); ?>" alt="<?php echo e($form['name']); ?>">
                                                </div>
                                                <input type="file" class="form-control" name="file-<?php echo e($form['key']); ?>">
                                                    
                                                <?php break; ?>
                                                
                                        <?php endswitch; ?>
                                        </div>
                                    </div>  
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                <a href="<?php echo e($_SERVER['HTTP_REFERER']); ?>"><button type="button" class="btn btn-primary">Lui lại</button></a>
                                <button type="submit" class="btn btn-primary">Gửi</button>
                                
                            </form>
                        </div>
                    </div>

                </div>
                <!-- end row -->

            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/admin/components/edit.blade.php ENDPATH**/ ?>