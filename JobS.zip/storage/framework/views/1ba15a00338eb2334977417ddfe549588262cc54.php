

<?php $__env->startSection('title', 'Company'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card-box">

                <table id="datatable" class="table table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                            <?php $__currentLoopData = $metadata['header']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item['name']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            <?php if(isset($metadata['operation']['operation']) && count($metadata['operation']['operation']) > 0): ?>
                                <th>Hành động</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $metadata['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <?php $__currentLoopData = $metadata['keys']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($key['component'])): ?>
                                    <?php switch($key['component']):
                                        case ('button'): ?>
                                            <td>
                                                <a href="/admin/<?php echo e($key['model']); ?>/<?php echo e($metadata['prefix']); ?>/<?php echo e($item->{$key['queryParam']['key']}); ?>">
                                                    <button class="btn btn-icon waves-effect waves-light btn-primary"> <i class="fas fa-list-ul"></i> </button>
                                                </a>
                                            </td>
                                        <?php break; ?>
                                        <?php case ('icon-button'): ?>
                                            <?php
                                                $value = $item->{$key['key']};
                                            ?>
                                            <td>
                                                <span class="mr-1"> <?php echo e(eval("return $value $key[condition] $key[value];") ? $key['textTrue'] : $key['textFalse']); ?> </span>
                                                <a href="<?php echo e($key['url']); ?>/<?php echo e($item['id']); ?>">
                                                    <button class="btn btn-icon waves-effect waves-light btn-primary"> <i class="fe-refresh-cw"></i> 
                                                        Đổi
                                                    </button>
                                                </a>
                                            </td>
                                        <?php break; ?>
                                    <?php endswitch; ?>
                                <?php else: ?>
                                    <td><?php echo e($item->{$key['key']}); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($metadata['operation']['operation']) && count($metadata['operation']['operation']) > 0): ?>
                            <td>
                                <div class="d-flex mt-1">
                                    <div class="mr-2">
                                        <a href="<?php echo e($metadata['prefix']); ?>/edit/<?php echo e($item->id); ?>">
                                            <button class="btn btn-icon waves-effect waves-light btn-warning"> <i class="fa fa-wrench"></i> </button>
                                        </a>
                                    </div>
                                    <div >
                                        <form action="<?php echo e(url('/admin/' . $metadata['prefix'] . '/' . $item->id)); ?>" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-icon waves-effect waves-light btn-dark"> <i class=" fas fa-trash-alt"></i> </button>
                                        </form>
                                    </div> 
                                </div>                            
                            </td> 
                            <?php endif; ?>
                            
                            </tr>                         
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
    
    <?php if(isset($metadata['operation']['roles']) && count($metadata['operation']['roles']) > 0): ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                
                <?php $__currentLoopData = $metadata['operation']['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php switch($role['action']):
                        case ('create'): ?>

                            <a href="/admin/<?php echo e($metadata['prefix']); ?>/create"><button type="button" class="btn btn-bordered-primary waves-effect  width-md waves-light">Thêm mới</button></a>            

                            <?php break; ?>
            
                    <?php endswitch; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div> 
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/admin/libs/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/libs/datatables/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/libs/datatables/buttons.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/libs/datatables/select.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- third party css end -->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('javascript'); ?>
    <!-- Vendor js -->
    <script src="<?php echo e(asset('assets/admin/js/vendor.min.js')); ?>"></script>

    <!-- third party js -->
    <script src="<?php echo e(asset('assets/admin/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
    <!-- third party js ends -->

    <!-- Datatables init -->
    <script src="<?php echo e(asset('assets/admin/js/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/admin/components/list.blade.php ENDPATH**/ ?>