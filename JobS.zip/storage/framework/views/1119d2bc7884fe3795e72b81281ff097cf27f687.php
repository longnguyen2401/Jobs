

<?php $__env->startSection('title', 'Company'); ?>

<?php $__env->startSection('page', 'Edit'); ?>

<?php echo $__env->make('admin.components.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\JobS\resources\views/admin/Company/edit.blade.php ENDPATH**/ ?>