@extends('admin.components.list')

@section('title', $metadata['list'][0]->company->name . ' Job')

@section('page', 'List')
