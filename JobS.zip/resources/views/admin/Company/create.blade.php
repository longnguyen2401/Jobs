@extends('admin.components.create')

@section('title', 'Company')

@section('page', 'Create')
