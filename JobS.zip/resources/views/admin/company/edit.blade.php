@extends('admin.components.edit')

@section('title', 'Company')

@section('page', 'Edit')
