@extends('admin.components.list')

@section('title', 'Company')

@section('page', 'List')
