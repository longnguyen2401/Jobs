<?php

namespace App\ModelOperation;

use App\ModelOperation\BaseOperation;

class JobOperation extends BaseOperation
{
    /**
     * The attributes prefix for each model.
     * 
     * @var string
     */
    protected string $prefix = 'Job';   
}


